CREATE SCHEMA `mdx_data`;
CREATE SCHEMA `mdx_players`;